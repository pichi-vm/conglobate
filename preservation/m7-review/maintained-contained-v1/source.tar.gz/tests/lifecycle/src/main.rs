// SPDX-License-Identifier: Apache-2.0
#![forbid(unsafe_code)]
mod contained;
mod domain_publication;
mod formatter_failures;
use conglobate::execution::{HelperInvocation, HelperProgram};
use std::{ffi::OsStr, path::Path};

#[derive(Debug)]
struct Lifecycle;
impl Lifecycle {
    fn run() -> Result<(), Box<dyn std::error::Error>> {
        if !Path::new("/conglobate-disposable-validation-vm").is_file() {
            return Err("disposable guest required".into());
        }
        let mut args = std::env::args_os();
        if args.next().as_deref() == Some(OsStr::new("/usr/bin/formatter-stall")) {
            formatter_failures::FormatterFailures::stall();
        }
        let args: Vec<_> = args.collect();
        if let Some(invocation) = HelperInvocation::parse(&args)? {
            invocation.execute(&HelperProgram::current()?);
        }
        match args.as_slice() {
            [mode] if mode == "formatter-failures" => formatter_failures::FormatterFailures::run(),
            [mode] if mode == "domain-publication" => domain_publication::DomainPublication::run(),
            [mode] if mode == "contained" => contained::Contained::run(),
            [mode] if mode == "contained-helper" => contained::Contained::helper(false),
            [mode] if mode == "contained-reject" => contained::Contained::helper(true),
            [mode] if mode == "contained-child" => contained::Contained::child(),
            _ => Err("expected lifecycle case or trusted helper invocation".into()),
        }
    }
}
fn main() {
    if let Err(error) = Lifecycle::run() {
        eprintln!("lifecycle fixture: {error}");
        std::process::exit(1);
    }
}
