// SPDX-FileCopyrightText: Advanced Micro Devices, Inc.
// SPDX-License-Identifier: Apache-2.0
use super::{ResolverInput, ResolverTarget};
use crate::storage::Workspace;
use rustix::{
    fs::{self, Mode},
    mount::{
        self, MountAttr, MountAttrFlags, MountPropagationFlags, MountSetAttrFlags, OpenTreeFlags,
    },
};
use std::{
    fs::File,
    io::{self, Write},
};

/// Detached read-only resolver mount backed by an anonymous file on the build
/// workspace. No pathname, writable descriptor or captured input bytes escape.
/// Closing an unattached mount releases its backing automatically. Once attached
/// in a command helper, that helper's private mount namespace owns its lifetime.
#[derive(Debug)]
pub struct ResolverMount {
    tree: File,
}
impl ResolverMount {
    pub fn prepare(input: &ResolverInput, workspace: &Workspace) -> io::Result<Self> {
        let mut backing = workspace.scratch()?;
        backing.write_all(input.bytes())?;
        fs::fchmod(backing.file(), Mode::from_raw_mode(0o444))?;
        let tree = mount::open_tree(
            backing.file(),
            "",
            OpenTreeFlags::AT_EMPTY_PATH
                | OpenTreeFlags::OPEN_TREE_CLONE
                | OpenTreeFlags::OPEN_TREE_CLOEXEC,
        )?;
        mount::mount_setattr(
            &tree,
            "",
            MountSetAttrFlags::AT_EMPTY_PATH,
            MountAttr::new(
                MountAttrFlags::MOUNT_ATTR_RDONLY
                    | MountAttrFlags::MOUNT_ATTR_NOSUID
                    | MountAttrFlags::MOUNT_ATTR_NODEV
                    | MountAttrFlags::MOUNT_ATTR_NOEXEC,
                MountAttrFlags::empty(),
                MountPropagationFlags::PRIVATE,
            ),
        )?;
        // The anonymous inode is retained by the detached mount; the only
        // writable descriptor is closed before a read-only owner is returned.
        drop(backing);
        Ok(Self { tree: tree.into() })
    }

    /// Dedicated helper only, before command admission. The target must have
    /// been selected in this helper's current private mount namespace. The
    /// caller retains its scaffold owner until commands and mounts are gone.
    /// Any setup failure is exit-only; namespace disposal removes the mount.
    pub fn attach(self, target: &ResolverTarget) -> io::Result<()> {
        mount::move_mount(
            &self.tree,
            "",
            target.handle(),
            "",
            mount::MoveMountFlags::MOVE_MOUNT_F_EMPTY_PATH
                | mount::MoveMountFlags::MOVE_MOUNT_T_EMPTY_PATH,
        )?;
        Ok(())
    }
}
