// SPDX-FileCopyrightText: Advanced Micro Devices, Inc.
// SPDX-License-Identifier: Apache-2.0
use super::{
    ExecutionStorage, Ready, Retained, Step, StepStorage, StorageLayout, TeardownCompletion,
    private, teardown::Released,
};
use crate::{
    network::{CommandNetwork, NetworkCleanupFailure},
    policy::{BoundDisabled, LabelPolicy},
    process::{ReapedChildren, Registered, Supervision},
    storage::{BootstrapVolumes, FailureDiagnostics, Mounted, Volume},
};
use std::{io, marker::PhantomData, time::Instant};

/// Storage layouts that may receive one command network. This marker is sealed
/// by StepStorage; NetworkedStorage does not implement it, preventing nesting.
pub trait NetworkEligibleStorage: ExecutionStorage {}
impl NetworkEligibleStorage for Volume<'_, '_, '_, Mounted> {}
impl NetworkEligibleStorage for BootstrapVolumes<'_, '_, '_, Mounted> {}

/// A command's storage and network move together through the step's retained
/// ownership states. Neither owner is available before descendant quiescence.
#[derive(Debug)]
pub struct NetworkedStorage<R: NetworkEligibleStorage> {
    storage: R,
    network: CommandNetwork,
}
impl<R: NetworkEligibleStorage> private::Storage for NetworkedStorage<R> {}
impl<R: NetworkEligibleStorage> StepStorage for NetworkedStorage<R> {}
impl<R: NetworkEligibleStorage> StorageLayout for NetworkedStorage<R> {
    type Unmounted = R::Unmounted;
}
impl<'l, R: NetworkEligibleStorage> Step<'l, Ready, R> {
    /// Consume network ownership while the registered helper is blocked on its
    /// volume input. Failed setup and teardown retain it with the assigned root.
    pub fn with_network(self, network: CommandNetwork) -> Step<'l, Ready, NetworkedStorage<R>> {
        Step {
            storage: Retained::new(NetworkedStorage {
                storage: self.storage.release(),
                network,
            }),
            policy: self.policy,
            resources: self.resources,
            _lease: PhantomData,
        }
    }
}
#[derive(Debug, thiserror::Error)]
pub enum NetworkFinalizationFailure<R: NetworkEligibleStorage> {
    #[error("command network cleanup: {failure}")]
    Network {
        failure: Box<NetworkCleanupFailure>,
        completion: TeardownCompletion<R>,
    },
    #[error("networked storage finalization: {0:?}")]
    Storage(R::FinalizationFailure),
}
impl<R: NetworkEligibleStorage> ExecutionStorage for NetworkedStorage<R> {
    type Finalized = R::Finalized;
    type FinalizationFailure = Box<NetworkFinalizationFailure<R>>;
    fn send(
        &self,
        policy: &LabelPolicy<BoundDisabled>,
        channel: &Supervision<Registered>,
        network: Option<&CommandNetwork>,
        deadline: Instant,
    ) -> io::Result<()> {
        if network.is_some() {
            return Err(io::Error::other("nested command networking is invalid"));
        }
        self.storage
            .send(policy, channel, Some(&self.network), deadline)
    }
    fn finalize(
        completion: TeardownCompletion<Self>,
    ) -> Result<Self::Finalized, Self::FinalizationFailure> {
        let TeardownCompletion { released, deadline } = completion;
        let Released {
            status,
            reaped,
            storage,
        } = released;
        let NetworkedStorage { storage, network } = storage;
        let completion = TeardownCompletion {
            released: Released {
                status,
                reaped,
                storage,
            },
            deadline,
        };
        match network.close(deadline) {
            Ok(()) => R::finalize(completion)
                .map_err(|failure| Box::new(NetworkFinalizationFailure::Storage(failure))),
            Err(failure) => Err(Box::new(NetworkFinalizationFailure::Network {
                failure,
                completion,
            })),
        }
    }
    fn retry_finalization(
        failure: Self::FinalizationFailure,
    ) -> Result<Self::Finalized, Self::FinalizationFailure> {
        match *failure {
            NetworkFinalizationFailure::Network {
                failure,
                completion,
            } => match failure.retry() {
                Ok(()) => R::finalize(completion)
                    .map_err(|failure| Box::new(NetworkFinalizationFailure::Storage(failure))),
                Err(failure) => Err(Box::new(NetworkFinalizationFailure::Network {
                    failure,
                    completion,
                })),
            },
            NetworkFinalizationFailure::Storage(failure) => R::retry_finalization(failure)
                .map_err(|failure| Box::new(NetworkFinalizationFailure::Storage(failure))),
        }
    }
    fn finalization_diagnostics(failure: &Self::FinalizationFailure) -> &FailureDiagnostics {
        match &**failure {
            NetworkFinalizationFailure::Network { failure, .. } => failure.diagnostics(),
            NetworkFinalizationFailure::Storage(failure) => R::finalization_diagnostics(failure),
        }
    }
    fn finalized_parts(finalized: Self::Finalized) -> (ReapedChildren, Self::Unmounted) {
        R::finalized_parts(finalized)
    }
}
